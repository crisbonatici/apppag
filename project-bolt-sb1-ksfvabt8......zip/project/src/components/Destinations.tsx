import React from 'react';
import { MapPin, Plane } from 'lucide-react';

const Destinations = () => {
  const destinations = [
    {
      name: "Sudeste Asiático",
      countries: "Tailandia, Vietnam, Singapur",
      image: "https://images.pexels.com/photos/1658967/pexels-photo-1658967.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      packages: 12
    },
    {
      name: "Europa Occidental",
      countries: "Francia, Italia, España",
      image: "https://images.pexels.com/photos/1386444/pexels-photo-1386444.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      packages: 18
    },
    {
      name: "América del Sur",
      countries: "Perú, Chile, Argentina",
      image: "https://images.pexels.com/photos/2613260/pexels-photo-2613260.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      packages: 8
    },
    {
      name: "África Oriental",
      countries: "Kenia, Tanzania, Uganda",
      image: "https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      packages: 6
    },
    {
      name: "Oceanía",
      countries: "Australia, Nueva Zelanda",
      image: "https://images.pexels.com/photos/1878293/pexels-photo-1878293.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      packages: 10
    },
    {
      name: "Oriente Medio",
      countries: "Emiratos, Jordania, Turquía",
      image: "https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      packages: 7
    }
  ];

  return (
    <section id="destinos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <Plane className="w-8 h-8 text-blue-600 mr-3" />
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-800">
              Destinos <span className="text-blue-600">Populares</span>
            </h2>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explora los destinos más fascinantes del mundo con nuestros paquetes especializados
          </p>
        </div>

        {/* Destinations grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {destinations.map((destination, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transform hover:scale-105 transition-all duration-300 cursor-pointer"
            >
              {/* Background image */}
              <div className="relative h-80">
                <img
                  src={destination.image}
                  alt={destination.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
              </div>

              {/* Content overlay */}
              <div className="absolute inset-0 flex flex-col justify-end p-6 text-white">
                <div className="transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                  <h3 className="text-2xl font-bold mb-2">{destination.name}</h3>
                  <p className="text-gray-200 mb-3 flex items-center">
                    <MapPin className="w-4 h-4 mr-1" />
                    {destination.countries}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {destination.packages} paquetes
                    </span>
                    <button className="opacity-0 group-hover:opacity-100 bg-white text-gray-800 px-4 py-2 rounded-full text-sm font-medium hover:bg-gray-100 transition-all duration-300">
                      Explorar
                    </button>
                  </div>
                </div>
              </div>

              {/* Hover effect overlay */}
              <div className="absolute inset-0 bg-blue-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          ))}
        </div>

        {/* Stats section */}
        <div className="mt-20 bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl p-8 text-white">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">50+</div>
              <div className="text-blue-100">Destinos</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">10k+</div>
              <div className="text-blue-100">Viajeros Felices</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">15</div>
              <div className="text-blue-100">Años de Experiencia</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">24/7</div>
              <div className="text-blue-100">Soporte</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Destinations;