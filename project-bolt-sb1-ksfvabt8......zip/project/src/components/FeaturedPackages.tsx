import React from 'react';
import { Star, Clock, Users, MapPin, Heart } from 'lucide-react';

const FeaturedPackages = () => {
  const packages = [
    {
      id: 1,
      title: "Bali Místico",
      subtitle: "Indonesia Paradisíaca",
      image: "https://images.pexels.com/photos/2474658/pexels-photo-2474658.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      price: 1299,
      originalPrice: 1599,
      duration: "7 días",
      groupSize: "Max 12",
      rating: 4.9,
      reviews: 156,
      highlights: ["Templos sagrados", "Playas vírgenes", "Spa tradicional"],
      featured: true
    },
    {
      id: 2,
      title: "París Romántico",
      subtitle: "Francia Elegante",
      image: "https://images.pexels.com/photos/338515/pexels-photo-338515.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      price: 899,
      originalPrice: 1199,
      duration: "5 días",
      groupSize: "Max 8",
      rating: 4.8,
      reviews: 203,
      highlights: ["Torre Eiffel", "Museo Louvre", "Crucero por Sena"]
    },
    {
      id: 3,
      title: "Tokio Futurista",
      subtitle: "Japón Moderno",
      image: "https://images.pexels.com/photos/2506923/pexels-photo-2506923.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      price: 1599,
      originalPrice: 1899,
      duration: "8 días",
      groupSize: "Max 10",
      rating: 4.9,
      reviews: 127,
      highlights: ["Shibuya Crossing", "Monte Fuji", "Templos zen"]
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4">
            Paquetes <span className="text-blue-600">Destacados</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Descubre nuestras experiencias más populares, cuidadosamente seleccionadas 
            para brindarte momentos inolvidables.
          </p>
        </div>

        {/* Packages grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {packages.map((pkg, index) => (
            <div 
              key={pkg.id} 
              className={`group relative bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transform hover:scale-105 transition-all duration-300 ${
                pkg.featured ? 'ring-4 ring-yellow-400 lg:scale-105' : ''
              }`}
            >
              {/* Featured badge */}
              {pkg.featured && (
                <div className="absolute top-4 left-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-gray-900 px-3 py-1 rounded-full text-sm font-semibold z-10">
                  ⭐ Más Popular
                </div>
              )}

              {/* Heart icon */}
              <button className="absolute top-4 right-4 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors z-10">
                <Heart className="w-5 h-5 text-gray-600 hover:text-red-500 transition-colors" />
              </button>

              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={pkg.image}
                  alt={pkg.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                
                {/* Price badge */}
                <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm rounded-lg px-3 py-2">
                  <div className="text-2xl font-bold text-gray-800">${pkg.price}</div>
                  <div className="text-sm text-gray-500 line-through">${pkg.originalPrice}</div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-2xl font-bold text-gray-800">{pkg.title}</h3>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium text-gray-600">{pkg.rating}</span>
                  </div>
                </div>

                <p className="text-blue-600 font-medium mb-4">{pkg.subtitle}</p>

                {/* Details */}
                <div className="flex items-center space-x-4 mb-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{pkg.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>{pkg.groupSize}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <span>{pkg.reviews} reseñas</span>
                  </div>
                </div>

                {/* Highlights */}
                <div className="mb-6">
                  <div className="flex flex-wrap gap-2">
                    {pkg.highlights.map((highlight, idx) => (
                      <span
                        key={idx}
                        className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm"
                      >
                        {highlight}
                      </span>
                    ))}
                  </div>
                </div>

                {/* CTA Button */}
                <button className="w-full bg-gradient-to-r from-blue-600 to-teal-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-200">
                  Ver Detalles
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* View all button */}
        <div className="text-center mt-12">
          <button className="bg-transparent border-2 border-blue-600 text-blue-600 px-8 py-4 rounded-full font-semibold text-lg hover:bg-blue-600 hover:text-white transition-all duration-300">
            Ver Todos los Paquetes
          </button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedPackages;