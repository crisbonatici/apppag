import React, { useState } from 'react';
import { Menu, X, MapPin, Phone, Mail } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      {/* Top bar */}
      <div className="bg-gradient-to-r from-blue-600 to-teal-600 text-white py-2">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Phone className="w-4 h-4" />
              <span>+1 (555) 123-4567</span>
            </div>
            <div className="flex items-center space-x-1">
              <Mail className="w-4 h-4" />
              <span>info@wanderlust.com</span>
            </div>
          </div>
          <div className="hidden md:block">
            <span>¡Descuentos especiales hasta 30% OFF!</span>
          </div>
        </div>
      </div>

      {/* Main navigation */}
      <nav className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <MapPin className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-800">WanderLust</h1>
          </div>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#inicio" className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium">
              Inicio
            </a>
            <a href="#paquetes" className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium">
              Paquetes
            </a>
            <a href="#destinos" className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium">
              Destinos
            </a>
            <a href="#testimonios" className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium">
              Testimonios
            </a>
            <a href="#contacto" className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium">
              Contacto
            </a>
            <button className="bg-gradient-to-r from-blue-600 to-teal-600 text-white px-6 py-2 rounded-full hover:shadow-lg transform hover:scale-105 transition-all duration-200">
              Reservar Ahora
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t pt-4">
            <div className="flex flex-col space-y-4">
              <a href="#inicio" className="text-gray-700 hover:text-blue-600 transition-colors">
                Inicio
              </a>
              <a href="#paquetes" className="text-gray-700 hover:text-blue-600 transition-colors">
                Paquetes
              </a>
              <a href="#destinos" className="text-gray-700 hover:text-blue-600 transition-colors">
                Destinos
              </a>
              <a href="#testimonios" className="text-gray-700 hover:text-blue-600 transition-colors">
                Testimonios
              </a>
              <a href="#contacto" className="text-gray-700 hover:text-blue-600 transition-colors">
                Contacto
              </a>
              <button className="bg-gradient-to-r from-blue-600 to-teal-600 text-white px-6 py-2 rounded-full w-full">
                Reservar Ahora
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;