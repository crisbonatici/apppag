import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      name: "María González",
      location: "Madrid, España",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      rating: 5,
      text: "Mi viaje a Bali fue absolutamente mágico. Cada detalle fue perfectamente planificado y el servicio fue excepcional. WanderLust superó todas mis expectativas.",
      trip: "Bali Místico - 7 días"
    },
    {
      id: 2,
      name: "Carlos Rodríguez",
      location: "Buenos Aires, Argentina",
      image: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      rating: 5,
      text: "La experiencia en París fue increíble. Los guías locales, el itinerario y la atención al detalle hicieron que fuera el viaje perfecto para nuestra luna de miel.",
      trip: "París Romántico - 5 días"
    },
    {
      id: 3,
      name: "Ana Martínez",
      location: "México DF, México",
      image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      rating: 5,
      text: "Tokio me fascinó completamente. La mezcla perfecta entre tradición y modernidad. WanderLust organizó cada momento para que fuera inolvidable.",
      trip: "Tokio Futurista - 8 días"
    },
    {
      id: 4,
      name: "Roberto Silva",
      location: "São Paulo, Brasil",
      image: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop",
      rating: 5,
      text: "El safari en África fue la aventura de mi vida. Ver los Big Five en su hábitat natural fue emocionante. Recomiendo WanderLust al 100%.",
      trip: "Safari Africano - 10 días"
    }
  ];

  return (
    <section id="testimonios" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4">
            Lo que dicen nuestros <span className="text-blue-600">Viajeros</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Miles de aventureros han confiado en nosotros para crear sus mejores recuerdos de viaje
          </p>
        </div>

        {/* Testimonials grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8 mb-12">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transform hover:scale-105 transition-all duration-300 relative"
            >
              {/* Quote icon */}
              <div className="absolute -top-4 left-8">
                <div className="bg-blue-600 p-3 rounded-full">
                  <Quote className="w-6 h-6 text-white" />
                </div>
              </div>

              {/* Content */}
              <div className="pt-4">
                {/* Rating */}
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                {/* Text */}
                <p className="text-gray-700 text-lg leading-relaxed mb-6 italic">
                  "{testimonial.text}"
                </p>

                {/* Trip info */}
                <div className="bg-blue-50 rounded-lg p-3 mb-6">
                  <p className="text-blue-700 font-medium text-sm">{testimonial.trip}</p>
                </div>

                {/* Author */}
                <div className="flex items-center">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
                    <p className="text-gray-600 text-sm">{testimonial.location}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust indicators */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="flex items-center justify-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">4.9/5</h3>
              <p className="text-gray-600">Calificación promedio</p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">98%</h3>
              <p className="text-gray-600">Clientes satisfechos</p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">1,247</h3>
              <p className="text-gray-600">Reseñas verificadas</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;